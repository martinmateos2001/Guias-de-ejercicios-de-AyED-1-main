def sumar(a, b):
    if(a%2==0):
        print(str(a) + " es un numero par")
    if(a==b):
        print(str(a) + " y " + str(b) + " son iguales")
    
    return a + b

def restar(a, b):
    return a - b

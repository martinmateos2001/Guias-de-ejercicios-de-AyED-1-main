a = 5
print(a)
print(type(a))
print(id(a))
a = "Hola mundo"
print(a)
print(type(a))
print(id(a))
a = 5
print(id(a))
a = 6
print(id(a))
b = "Hola Mundo"
print(id(b))
print(int(b))

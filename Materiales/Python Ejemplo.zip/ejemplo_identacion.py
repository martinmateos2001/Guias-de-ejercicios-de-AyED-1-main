
def suma(a: int, b: int)->int:
    resultado: int = a + b
    return resultado

print(suma(2,3));



for i in range(500, 1000, 100):
    print(i)


numero: int = int(input('Ingresa un número. 0 para terminar: '))

while(numero != 0):
    print('Usted ingresó: ', numero)
    numero = int(input('Ingresa un número. 0 para terminar: '))
   
print('Fin del programa.')
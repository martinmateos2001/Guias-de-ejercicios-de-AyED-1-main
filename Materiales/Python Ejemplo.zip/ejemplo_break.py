 
while(True):
    numero = int(input('Ingresa un número. 0 para terminar: '))
    print('Usted ingresó: ', numero)
    if(numero==0):
        break
   
print('Fin del programa.')
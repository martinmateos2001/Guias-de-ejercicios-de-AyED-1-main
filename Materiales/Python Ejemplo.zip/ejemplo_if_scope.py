x: int = 10
if(x > 5):
    y: int = 6
else:
    y: int = 12

print("y = " + str(y))
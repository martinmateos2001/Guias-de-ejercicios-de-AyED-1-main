def ejemploLocalScope():
    x: int = 19
    print("x: " + str(x))
     

ejemploLocalScope()
print("x: " + str(x))